﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tp2Grafos
{
    class Labirinto
    {
        private string[,] mapaLabirinto;
        private int linhas;
        private int colunas;

        public string[,] MapaLabirinto
        {
            get
            {
                return mapaLabirinto;
            }

            set
            {
                mapaLabirinto = value;
            }
        }
        
        public int Colunas
        {
            get
            {
                return colunas;
            }

            set
            {
                colunas = value;
            }
        }

        public int Linhas
        {
            get
            {
                return linhas;
            }

            set
            {
                linhas = value;
            }
        }

        public Labirinto(int linha, int coluna)
        {
            MapaLabirinto = new string[linha, coluna];
            Linhas = linha;
            Colunas = coluna;
        }

        public Labirinto()
        {
            this.mapaLabirinto = new string [0,0];
            this.linhas = 0;
            this.colunas = 0;
        }
    }
}
