﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace Tp2Grafos
{
    class Program
    {
        public static List<string> CaminhosProibidos = new List<string>();
        public static Queue<string> FilaCaminhos = new Queue<string>();
        public static List<Robo> ListaSucessores = new List<Robo>();

        static void Main()
        {
            // Define o caminho onde está localizado o arquivo que sera lido.
            string CaminhoTxt = @"D:\César\Área de Trabalho\Tp2Grafos\Arquivo Entrada.txt";
            //Cria um vetor para armazenar o txt
            string[] arquivo, arquivoAux;
            int[] primeiralinha;
            int TamLinhas, TamColunas, EnergiaIni;
            //Preenche o vetor com a leitura do arquivo
            arquivo = LerArquivo(CaminhoTxt);
            Console.ReadKey();
            //Preenche o vetor primeira linha com os 3 valores iniciais
            primeiralinha = BuscaValoresPrimeiraLinha(arquivo[0]);
            TamLinhas = primeiralinha[0];
            TamColunas = primeiralinha[1];
            EnergiaIni = primeiralinha[2];
            //Cria objeto Labirinto
            Labirinto Principal = new Labirinto(TamLinhas, TamColunas);
            //Cria vetor auxiliar
            arquivoAux = new string[arquivo.Length - 1];
            //Carrega arquvio auxiliar
            for (int i = 0; i < arquivoAux.Length; i++)
            {
                arquivoAux[i] = arquivo[i + 1];
            }
            string estado = String.Join("",arquivoAux);
            Principal = PreencherLabirinto(estado, Principal);

            
        }

        //Metodo que carrega o Labirinto
        public static Labirinto PreencherLabirinto(string mapa, Labirinto Principal)
        {
            int contador = 0;
            string proibido = "";
            do
            {
                int i = 0;
                int j = 0;

                for (i = 0; i < Principal.Linhas; i++)
                {
                    for (j = 0; j < Principal.Colunas; j++)
                    {
                        Principal.MapaLabirinto[i, j] = mapa[contador].ToString();
                        contador++;
                        if (Principal.MapaLabirinto[i, j] == "#")
                        {
                            proibido = i.ToString()+","+j.ToString();
                            CaminhosProibidos.Add(proibido);
                        }
                            

                    }
                }
            }
            while (contador < mapa.Length);

            return Principal;
        } 
        //Metodo faz a leitura do arquivo .txt e retorna o vetor com o mesmo.
        public static string[] LerArquivo(string CaminhoTxt)
        {
            //Lê todas as linhas do arquivo e as salva em um vetor de string.
            string[] linhas = File.ReadAllLines(CaminhoTxt);
            return linhas;
        }
        //Metodo fara a busca dos três primeiros valores contidos na primeira linha do arquivo.
        public static int[] BuscaValoresPrimeiraLinha(string primeiralinha)
        {
            //Cria vetor que armazenara os 3 valores da primeira linha
            int[] valoresinciais = new int[3];
            //Int para controle do foreach
            int controle = 0;
            //Transforma a primeira linha em uma nova string sem espaços em branco
            string [] separador = primeiralinha.Split(' ');
            //Para cada string entre os espaços é adicionado uma posição no vetor de valoresiniciais
            foreach (string numero in separador)
            {
                valoresinciais[controle] = int.Parse(numero);
                controle++;
            }
            return valoresinciais;
        }
        //Metodo que busca a posição inicial do robo
        public static string BuscaPosicaoInicialRobo(Labirinto Principal)
        {
            string posicao = "";

            for (int i = 0; i < Principal.Linhas; i++)
            {
                for (int j = 0; j < Principal.Colunas; j++)
                {
                    if (Principal.MapaLabirinto[i, j] == "R")
                        posicao = (i * 10 + j).ToString();
                }
            }

            return posicao;   
        }
        //Metodo que busca a posição Bateria
        public static string BuscaPosicaoBateria(Labirinto Principal)
        {
            string posicao = "";

            for (int i = 0; i < Principal.Linhas; i++)
            {
                for (int j = 0; j < Principal.Colunas; j++)
                {
                    if (Principal.MapaLabirinto[i, j] == "R")
                        posicao = (i * 10 + j).ToString();
                }
            }

            return posicao;
        }
        //Metodo que busca a posição Saida
        public static string BuscaPosicaoSaida(Labirinto Principal)
        {
            string posicao = "";

            for (int i = 0; i < Principal.Linhas; i++)
            {
                for (int j = 0; j < Principal.Colunas; j++)
                {
                    if (Principal.MapaLabirinto[i, j] == "S")
                        posicao = (i * 10 + j).ToString();
                }
            }

            return posicao;
        }
        //Metodo que move o robo
        public static string ExecutaMovimento(Robo Personagem, Labirinto Mapa, string Movimento)
        {
            Robo aux = new Robo();
            aux = Personagem;
            bool move = true;
            string result = "Falha no movimento";
            //CIMA
            if (Movimento == "Cima")
            {
                for (int cont = 0; cont < CaminhosProibidos.Count; cont++)
                {
                    if (CaminhosProibidos[cont] == (aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString()))
                    {
                        move = false;
                    }
                }


                if (move == true)
                {
                    aux.Posicaoanterior = aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString();
                    aux.ColunaAtual = aux.ColunaAtual;
                    aux.LinhaAtual = aux.LinhaAtual - 1;
                    aux.IdPai1 = aux.Id1;
                    aux.Id1 = aux.Id1 + 1;
                    if (aux.Visitado == false)
                    {

                        if (aux.Custo < aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                aux.Custo = aux.Custo + 1;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                aux.Custo = aux.Custo + 3;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                aux.Posicaoinicial = "S";
                                aux.Custo = aux.Custo + 1;
                            }
                            ListaSucessores.Add(aux);
                            result = "Sucesso no movimento";
                        }
                        else if (aux.Custo == aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                            {
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                                result = "Bateria Recarregada";
                            }
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                result = "Falha no movimento";
                            }
                        }
                        else if (aux.Custo > aux.EnergiaInicial)
                        {
                            result = "Bateria esgotada";
                        }
                    }
                }


            }

            //BAIXO
            if(Movimento == "Baixo")
            {
                for (int cont = 0; cont < CaminhosProibidos.Count; cont++)
                {
                    if (CaminhosProibidos[cont] == (aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString()))
                    {
                        move = false;
                    }
                }


                if (move == true)
                {
                    aux.Posicaoanterior = aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString();
                    aux.ColunaAtual = aux.ColunaAtual;
                    aux.LinhaAtual = aux.LinhaAtual + 1;
                    aux.IdPai1 = aux.Id1;
                    aux.Id1 = aux.Id1 + 1;
                    if (aux.Visitado == false)
                    {

                        if (aux.Custo < aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                aux.Custo = aux.Custo + 1;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                aux.Custo = aux.Custo + 3;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                aux.Posicaoinicial = "S";
                                aux.Custo = aux.Custo + 1;
                            }
                            ListaSucessores.Add(aux);
                            result = "Sucesso no movimento";
                        }
                        else if (aux.Custo == aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                            {
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                                result = "Bateria Recarregada";
                            }
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                result = "Falha no movimento";
                            }
                        }
                        else if (aux.Custo > aux.EnergiaInicial)
                        {
                            result = "Bateria esgotada";
                        }
                    }
                }
            }

            //DIREITA
            if (Movimento == "Direita")
            {
                for (int cont = 0; cont < CaminhosProibidos.Count; cont++)
                {
                    if (CaminhosProibidos[cont] == (aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString()))
                    {
                        move = false;
                    }
                }


                if (move == true)
                {
                    aux.Posicaoanterior = aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString();
                    aux.ColunaAtual = aux.ColunaAtual+1;
                    aux.LinhaAtual = aux.LinhaAtual;
                    aux.IdPai1 = aux.Id1;
                    aux.Id1 = aux.Id1 + 1;
                    if (aux.Visitado == false)
                    {

                        if (aux.Custo < aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                aux.Custo = aux.Custo + 1;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                aux.Custo = aux.Custo + 3;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                aux.Posicaoinicial = "S";
                                aux.Custo = aux.Custo + 1;
                            }
                            ListaSucessores.Add(aux);
                            result = "Sucesso no movimento";
                        }
                        else if (aux.Custo == aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                            {
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                                result = "Bateria Recarregada";
                            }
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                result = "Falha no movimento";
                            }
                        }
                        else if (aux.Custo > aux.EnergiaInicial)
                        {
                            result = "Bateria esgotada";
                        }
                    }
                }
            }

            //ESQUERDA
            if (Movimento == "Esquerda")
            {
                for (int cont = 0; cont < CaminhosProibidos.Count; cont++)
                {
                    if (CaminhosProibidos[cont] == (aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString()))
                    {
                        move = false;
                    }
                }


                if (move == true)
                {
                    aux.Posicaoanterior = aux.LinhaAtual.ToString() + "," + aux.ColunaAtual.ToString();
                    aux.ColunaAtual = aux.ColunaAtual-1;
                    aux.LinhaAtual = aux.LinhaAtual;
                    aux.IdPai1 = aux.Id1;
                    aux.Id1 = aux.Id1 + 1;
                    if (aux.Visitado == false)
                    {

                        if (aux.Custo < aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                aux.Custo = aux.Custo + 1;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                aux.Custo = aux.Custo + 3;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                aux.Posicaoinicial = "S";
                                aux.Custo = aux.Custo + 1;
                            }
                            ListaSucessores.Add(aux);
                            result = "Sucesso no movimento";
                        }
                        else if (aux.Custo == aux.EnergiaInicial && aux.Visitado == false)
                        {
                            if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "~")
                                result = "Falha no movimento";
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "B")
                            {
                                aux.EnergiaInicial = aux.EnergiaInicial * 2;
                                result = "Bateria Recarregada";
                            }
                            else if (Mapa.MapaLabirinto[aux.LinhaAtual, aux.ColunaAtual] == "S")
                            {
                                result = "Falha no movimento";
                            }
                        }
                        else if (aux.Custo > aux.EnergiaInicial)
                        {
                            result = "Bateria esgotada";
                        }
                    }
                }
            }

            return result;
        }

    }
}
