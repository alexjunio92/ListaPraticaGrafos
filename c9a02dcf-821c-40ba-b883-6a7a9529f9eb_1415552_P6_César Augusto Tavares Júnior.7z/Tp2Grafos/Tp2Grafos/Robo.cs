﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tp2Grafos
{
    class Robo
    {
        private int Id;
        private int IdPai;
        private int energiaInicial;
        private int linhaAtual;
        private int colunaAtual;
        private string posicaoanterior;
        private string posicaoinicial; 
        private string moveu;
        private int custo;
        private bool visitado;


        public int EnergiaInicial
        {
            get
            {
                return energiaInicial;
            }

            set
            {
                energiaInicial = value;
            }
        }

        public int LinhaAtual
        {
            get
            {
                return linhaAtual;
            }

            set
            {
                linhaAtual = value;
            }
        }

        public int ColunaAtual
        {
            get
            {
                return colunaAtual;
            }

            set
            {
                colunaAtual = value;
            }
        }

        public string Posicaoanterior
        {
            get
            {
                return Posicaoanterior;
            }

            set
            {
                Posicaoanterior = value;
            }
        }

        public string Posicaoinicial
        {
            get
            {
                return posicaoinicial;
            }

            set
            {
                posicaoinicial = value;
            }
        }

        public string Moveu
        {
            get
            {
                return moveu;
            }

            set
            {
                moveu = value;
            }
        }

        public int Custo
        {
            get
            {
                return custo;
            }

            set
            {
                custo = value;
            }
        }

        public bool Visitado
        {
            get
            {
                return visitado;
            }

            set
            {
                visitado = value;
            }
        }

        public int Id1
        {
            get
            {
                return Id;
            }

            set
            {
                Id = value;
            }
        }

        public int IdPai1
        {
            get
            {
                return IdPai;
            }

            set
            {
                IdPai = value;
            }
        }

        public Robo()
        {
            this.energiaInicial = 0;
            this.linhaAtual = 0;
            this.colunaAtual = 0;
            this.posicaoanterior = "";
            this.posicaoinicial = "";
            this.moveu = "";
            this.custo = "";
            this.visitado = false;
        }

        public Robo(int energiainicial, int linhaatual, int colunaatual, string posicaoanterior, string posicaoinicial, string moveu, int custo, bool visitado)
        {
            EnergiaInicial = energiaInicial;
            LinhaAtual = linhaAtual;
            ColunaAtual = colunaAtual;
            Posicaoanterior = posicaoanterior;
            Posicaoinicial = posicaoinicial;
            Moveu = moveu;
            Custo = custo;
            Visitado = visitado;
        }

    }
}
