﻿/*

Implementação das estruturas de dados Grafo e Listas foram adaptadas do livro: 

[Ziviani, 2006] Projeto de Algoritmos com Implementações em Java e C++.
Nivio Ziviani. 2006, 642 pp. Editora Thomson, ISBN 8522105251.

*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using List;

namespace Grafo
{
    public class GrafoLista : Grafo
    {     
        private Lista[] adj;
        private int numVertices;

        public GrafoLista(int numVertices)
        {
            this.adj = new Lista[numVertices];
            this.numVertices = numVertices;

            for (int i = 0; i < this.numVertices; i++)
                this.adj[i] = new Lista();
        }

        public void insereAresta(int v1, int v2, int peso)
        {
            Aresta a = new Aresta(v1, v2, peso);

            this.adj[v1].insere(a);
        }

        public bool existeAresta(int v1, int v2, int peso)
        {
            Aresta a = new Aresta(v1, v2, peso);

            return (this.adj[v1].pesquisa(a));
        }

        public bool listaAdjVazia(int v)
        {
            return this.adj[v].vazia();
        }

        public bool retiraAresta(int v1, int v2, int peso)
        {
            Aresta a = new Aresta(v1, v2, peso);

            Aresta item = (Aresta) this.adj[v1].retira(a);
            return item != null ? true : false;
        }

        public Aresta primeiroListaAdj(int v)
        {
            // Retorna a primeira aresta que o vértice v participa ou
            // null se a lista de adjacência de v for vazia
            Aresta item = (Aresta)this.adj[v].Primeiro();
            return item != null ? new Aresta(v, item.v2, item.peso) : null;
        }

        public Aresta proxAdj(int v)
        {
            // Retorna a próxima aresta que o vértice v participa ou
            // null se a lista de adjacência de v estiver no fim
            Aresta item = (Aresta)this.adj[v].proximo();
            return item != null ? new Aresta(v, item.v2, item.peso) : null;
        }

        public void imprime()
        {
            for (int i = 0; i < this.numVertices; i++)
            {
                Console.Write("Vertice " + i);
                Aresta item = (Aresta)this.adj[i].Primeiro();
                while (item != null)
                {
                    Console.Write(" -> " + item.v2 + " ( " + item.peso + " )");
                    item = (Aresta)this.adj[i].proximo();
                }

                Console.WriteLine();
            }
            
        }

        public int get_numVertices()
        {
            return this.numVertices;
        }

        public int get_grauSaidaVertice(int i)
        {
            return this.adj[i].quantidade();
        }

        public GrafoLista grafoTransposto()
        {
            GrafoLista grafoT = new GrafoLista(this.numVertices);
            for (int v = 0; v < this.numVertices; v++)
                if (!this.listaAdjVazia(v))
                {
                    Aresta adj = this.primeiroListaAdj(v);
                    while (adj != null)
                    {
                        grafoT.insereAresta(adj.v2, adj.v1, adj.peso);
                        adj = this.proxAdj(v);
                    }
                }

            return grafoT;
        }

        //Lista 2

        //Lista 2.1
        public bool isAdjacente(int v1, int v2)
        {
            return adj[v1].pesquisa(v2);
        }
        //Lista 2.2
        public int getGrau(int v1)
        {
            return adj[v1].quantidade();
        }
        //Lista 2.3
        public bool isRegular(Grafo G)
        {
            int x = adj[0].quantidade();
            bool retorno = true;
            for (int i =1; i < G.get_numVertices(); i++)
            {
                 if (adj[i].quantidade() != x)
                {
                    retorno = false;
                    break;
                }else
                {
                    retorno = true;
                }
            }
            return retorno;
            
        }
        //Lista 2.4
        public bool isIsolado(int v1)
        {
            return adj[v1].quantidade()==0;
            
        }
        //Lista 2.5
        public bool isPendente(int v1) {
            return adj[v1].quantidade() == 1;
            
        }
        //Lista 2.6
        /*public bool isNulo(Grafo G) {
            for (int i = 0; i < G.get_numVertices(); i++)
            {
                if (adj[i].quantidade()==0)
                {

                }                
            }            
        }*/
        //Lista 2.7
        public bool isCompleto(Grafo G)
        {
            S
        }
    }


}

