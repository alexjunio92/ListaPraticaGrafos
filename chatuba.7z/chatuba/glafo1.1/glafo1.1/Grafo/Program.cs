﻿/*

Implementação das estruturas de dados Grafo e Listas foram adaptadas do livro: 

[Ziviani, 2006] Projeto de Algoritmos com Implementações em Java e C++.
Nivio Ziviani. 2006, 642 pp. Editora Thomson, ISBN 8522105251.

*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafo
{
    class Program
    {

        /* -----------

            O arquivo contento uma instância do grafo deve ser criado da seguinte maneira:

            - Primeira linha: número de vértices
            - Da segunda até a n-ésima linha: arestas do grafo. Três números inteiros separados por espaço simples,
            em que o primeiro número representa o vértice de origem da aresta, o segundo número o vértice de destino e o
            terceiro número o peso da aresta. 

            Para grafos não direcionados, deve-se criar uma nova linha para cada aresta, invertendo os vértices de origem
            e destino. Ou no código do programa, criar uma função para leitura do grafo que instancie grafos não direcionados.
            Neste caso, quando inserir uma aresta, inserir também outra aresta invertendo os vértices de origem e destino.

            Exemplo de um arquivo contendo um grafo (peso 1 para todas as arestas) de 5 vértices e 6 arestas:
            5
            0 1 1
            0 2 1
            0 3 1
            2 1 1
            2 3 1
            4 3 1            

        ------------- */
        private static void instanciaGrafo (StreamReader input, Grafo G)
        {
            int v1, v2, peso;
            String[] aresta;

            while (!input.EndOfStream)
            {
                aresta = input.ReadLine().Split(' ');

                v1 = int.Parse(aresta[0]);
                v2 = int.Parse(aresta[1]);
                peso = int.Parse(aresta[2]);

                G.insereAresta(v1, v2, peso);
                //G.insereAresta(v2, v1, peso); //Para grafos não-direcoinados.

            }            

        }

        /* -----------

            Insstancia um grafo com matriz de adjacência

        ------------- */
        public static GrafoMatriz instanciaGrafoDoArquivo (String filename, GrafoMatriz G)
        {
            StreamReader input = new StreamReader(filename);

            int numeroDeVertices = int.Parse(input.ReadLine());
           
            G = new GrafoMatriz(numeroDeVertices);

            instanciaGrafo(input, G);

            input.Close();

            return G;

        }

        /* -----------

            Insstancia um grafo com lista de adjacência

        ------------- */
        public static GrafoLista instanciaGrafoDoArquivo (String filename, GrafoLista G)
        {
            StreamReader input = new StreamReader(filename);

            int numeroDeVertices = int.Parse(input.ReadLine());

            G = new GrafoLista(numeroDeVertices);

            instanciaGrafo(input, G);

            input.Close();

            return G;
        }

        static void Main(string[] args)
        {

            GrafoLista G = null;
            String filename = @"c:\users\984479.pucminas\desktop\filetest.txt";

            G = instanciaGrafoDoArquivo(filename, G);

            G.imprime();

            G = G.grafoTransposto();

            Console.WriteLine();

            G.imprime();

            Console.ReadKey();


        }
    }
}
