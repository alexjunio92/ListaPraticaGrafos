﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace glafos
{
    /*
    Considere um grafo não dirigido:    
        1. bool isadjacente (Vertice v1, Vertice v2) { }
        2. int getGrau (Vertice v1) { }
        3. bool isRegular (Grafo G) { }
        4. bool isIsolado (Vertice v1) { }
        5. bool isPedente (Vertice v1) { }
        6. bool isNulo (Grafo G) { }
        7. bool isCompleto (Grafo G) { }
        8. bool isConexo (Grafo G) { }
        9. bool isBipartido (Grafo G) { }
        10. Grafo getComplementar (Grafo G) { }
        11. bool isEuleriano (Grafo G ) { }
        12. bool isUnicursal (Grafo G ) { }
        13. bool isHamiltoniano (Grafo G ) { }
    Considere um grafo dirigido:
        14. bool hasCiclo (Grafo G) { }
        15. int getGrauEntrada (Vertice v1) { }
        16. void ordenacaoTopologica (Grafo G) { } //verifique se o grafo é acíclico antes
        17. Grafo getTransposto (Grafo G) { }
        18. bool isFConexo (Grafo G) { }   
    */

    class Program
    {

        //static void GeraGrafoVet(int[,] g)
        //{
        //    Random r = new Random();
        //    for (int i = 0; i < g.GetLength(0); i++)
        //    {
        //        for (int j = 0; j < g.GetLength(1); j++)
        //        {
        //            if (i != j)
        //                g[i, j] = r.Next(2);
        //        }
        //    }
        //}
        static void GeraGrafoNaoDirecionadoVet(int[,] g)
        {
            Random r = new Random();
            for (int i = 0; i < g.GetLength(0); i++)
            {
                if (i < (g.GetLength(0) / 2))
                    for (int j = 0; j < g.GetLength(1); j++)
                    {
                        //if (true) //verificar necessidade
                        //{  
                        if (i != j)
                        {
                            g[i, j] = r.Next(2);
                            g[j, i] = g[i, j];
                        }
                        //}
                    }
            }
        }
        static void GeraGrafoDirecionadoVet(int[,] g)
        {
            Random r = new Random();
            for (int i = 0; i < g.GetLength(0); i++)
            {
                for (int j = 0; j < g.GetLength(1); j++)
                {
                    g[i, j] = r.Next(2);
                }
            }
        }
        static void PrintGrafoVet(int[,] g)
        {
            for (int i = 0; i < g.GetLength(0); i++)
            {
                for (int j = 0; j < g.GetLength(1); j++)
                {
                    Console.Write(g[i, j] + "\t");
                }
                Console.Write("\n");
            }
            Console.Write("\n\n");
        }
        static void MoveGrafoVetToList(int[,] gV, List<int>[] gL)
        {
            for (int i = 0; i < gV.GetLength(0); i++)
            {
                gL[i] = new List<int>();
                for (int j = 0; j < gV.GetLength(1); j++)
                {
                    if (gV[i, j] == 1)
                    {
                        gL[i].Add(j);
                    }
                }
            }
        }
        static void PrintGrafoList(List<int>[] g)
        {
            char[] letras = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            for (int i = 0; i < g.Length; i++)
            {
                Console.Write("Vértice " + letras[i] + "->\t");
                foreach (int v in g[i])
                {
                    Console.Write(letras[v] + "\t");
                }
                Console.Write("\n");
            }

        }
        static void Main(string[] args)
        {
            //Lista[] l = new Lista[10];
            //l[0].insert(1);
            //l[1].insert(0);
            //l[2].insert(0);
            try
            {

                Console.WriteLine("Digite o número de vértices para ser gerado um grafo aleatoriamente. (Número máximo: 26)");
                int x = int.Parse(Console.ReadLine());
                List<int>[] Grafo = new List<int>[x];
                int[,] glafo = new int[x, x];
                GeraGrafoNaoDirecionadoVet(glafo);
                PrintGrafoVet(glafo);
                Console.ReadKey();
                MoveGrafoVetToList(glafo, Grafo);
                PrintGrafoList(Grafo);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro encontrado: \n" + ex.Message);
                //goto ;
            }

            Console.ReadKey();


        }
    }
}
