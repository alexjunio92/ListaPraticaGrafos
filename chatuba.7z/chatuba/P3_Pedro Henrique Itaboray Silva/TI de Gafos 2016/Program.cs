﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_de_Gafos_2016
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] Areas;
            int[,] Alunos;
            string[] teste = File.ReadAllLines("areaPesquisa20.txt");
            Areas = new int[teste.Length, teste.Length];
            string[] teste2;
            for (int i = 0; i < teste.Length ; i++)
            {
                teste2 = teste[i].Split(' ');
                for (int j = 0; j < teste.Length ; j++)
                {
                    Areas[i, j] = int.Parse(teste2[j]);
                }
            }
           
            teste = File.ReadAllLines("entrada99.txt");
            Alunos = new int[teste.Length, 2];
            for (int i = 0; i < teste.Length; i++)
            {
                Alunos[i, 0] = int.Parse(teste[i].Split(' ')[0]);
                Alunos[i, 1] = int.Parse(teste[i].Split(' ')[1]);
            }
            Console.Write("Digite o número de Professores: ");
            int k = int.Parse(Console.ReadLine());

            GrafoArestas teste3 = new GrafoArestas();
            teste3.montarGrafo(Alunos, Areas);
            GrafoArestas AGM = teste3.Kruskal();
            Console.Clear();

            for (int i = 0; i < k - 1; i++)
            {
                AGM.Arestas.Sort((x, y) => x.Peso < y.Peso ? -1 : 1);

                Aresta backup = AGM.Arestas.Last();
                AGM.Arestas.Remove(AGM.Arestas.Last());
                if (!AGM.Arestas.Exists(x => x.AlunoA == backup.AlunoA || x.AlunoB == backup.AlunoA))
                {
                    AGM.Arestas.Add(new Aresta(backup.AlunoA, -1, -1));
                }
                if (!AGM.Arestas.Exists(x => x.AlunoB == backup.AlunoB || x.AlunoA == backup.AlunoB))
                {
                    AGM.Arestas.Add(new Aresta(backup.AlunoB, -1, -1));
                }
            }
            
          
            Console.Clear();

            foreach (var aresta in AGM.Arestas)
            {
                Console.WriteLine("{0}, {1}, {2}", aresta.AlunoA + 1, aresta.AlunoB + 1, aresta.Peso);
            }
            Console.ReadKey();

            BuscaEmProfundidade busca = new BuscaEmProfundidade(AGM);
            Console.Clear();
            busca.buscaEmProfundidade();
            Console.ReadKey();
        }
    }
}
