﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI_de_Gafos_2016
{
    public class GrafoArestas : Grafo
    {
        
        List<Aresta> arestas;
        int[] chefes;

        public List<Aresta> Arestas
        {
            get
            {
                return arestas;
            }

            set
            {
                arestas = value;
            }
        }

        public GrafoArestas()
        {
            arestas = new List<Aresta>();
        }

        public GrafoArestas(int tamanho)
        {
            arestas = new List<Aresta>();
            chefes = new int[tamanho];
        }

        public void montarGrafo(int[,] Alunos, int[,] Pesos)
        {
            chefes = new int[Alunos.GetLength(0)];
            for (int i = 0; i < chefes.Length; i++)
            {
                chefes[i] = -1;
            }
            for (int i = 0; i < Alunos.GetLength(0); i++)
            {
                for (int j = i; j < Alunos.GetLength(0); j++)
                {
                    if (i != j)
                    {
                        Arestas.Add(new Aresta(i, j, Pesos[Alunos[i, 1] - 1, Alunos[j, 1] - 1]));
                    }
                }
            }
        }

        public GrafoArestas Kruskal()
        {
            GrafoArestas AGM = new GrafoArestas(chefes.Length);
            
            arestas.Sort((x, y) => (x.Peso < y.Peso ? -1 : 1));
            int verticesColocados = 1;
            int indice = -1;
                foreach (var aresta in arestas)
                {
                    if (chefes[aresta.AlunoA] == -1 && chefes[aresta.AlunoB] == -1)
                    {
                        indice++;
                        chefes[aresta.AlunoA] = indice;
                        chefes[aresta.AlunoB] = indice;
                        AGM.Arestas.Add(aresta);
                        verticesColocados++;
                    }
                    else if (chefes[aresta.AlunoA] == -1 && chefes[aresta.AlunoB] != -1)
                    {
                        chefes[aresta.AlunoA] = chefes[aresta.AlunoB];
                        AGM.Arestas.Add(aresta);
                        verticesColocados++;
                    }
                    else if (chefes[aresta.AlunoB] == -1 && chefes[aresta.AlunoA] != -1)
                    {
                        chefes[aresta.AlunoB] = chefes[aresta.AlunoA];
                        AGM.Arestas.Add(aresta);
                        verticesColocados++;
                    }
                    else if ((chefes[aresta.AlunoA] != -1 && chefes[aresta.AlunoB] != -1) && (chefes[aresta.AlunoA] != chefes[aresta.AlunoB]))
                    {
                        if (chefes[aresta.AlunoA] < chefes[aresta.AlunoB])
                        {
                            for (int i = 0; i < chefes.Length; i++)
                            {
                                if (chefes[i] == chefes[aresta.AlunoB] && (i != aresta.AlunoB))
                                {
                                    chefes[i] = chefes[aresta.AlunoA];
                                }
                            }
                            chefes[aresta.AlunoB] = chefes[aresta.AlunoA];
                        }
                        else
                        {
                            for (int i = 0; i < chefes.Length; i++)
                            {
                                if (chefes[i] == chefes[aresta.AlunoA] && (i != aresta.AlunoA))
                                {
                                    chefes[i] = chefes[aresta.AlunoB];
                                }
                            }
                            chefes[aresta.AlunoA] = chefes[aresta.AlunoB];
                        }
                        AGM.Arestas.Add(aresta);
                        verticesColocados++;
                    }
                    //if (!(chefes[aresta.AlunoA] == chefes[aresta.AlunoB]))
                    //{
                    //    chefes[aresta.AlunoB] = chefes[aresta.AlunoA];
                    //    AGM.Arestas.Add(aresta);
                    //    verticesColocados++;
                    //}
                    if (!(verticesColocados < chefes.Length))
                    {
                        break;
                    }
            }
            return AGM;
        }
        
        public void insereAresta(int v1, int v2, int peso)
        {
            arestas.Add(new Aresta(v1, v2, peso));
        }

        public bool existeAresta(int v1, int v2, int peso)
        {
            return arestas.Exists(x => x.AlunoA == v1 && x.AlunoB == v2 && x.Peso == peso) || arestas.Exists(x => x.AlunoA == v2 && x.AlunoB == v1 && x.Peso == peso);
        }

        public bool listaAdjVazia(int v)
        {
            return (arestas.Exists(x => x.AlunoA == v && x.AlunoB == -1));
        }

        public bool retiraAresta(int v1, int v2, int peso)
        {
            return arestas.Remove(arestas.Find(x => x.AlunoA == v1 && x.AlunoB == v2 && x.Peso == peso));
        }

        public Aresta primeiroListaAdj(int v)
        {
            return arestas.FirstOrDefault(x => x.AlunoA == v || x.AlunoB == v);
        }

        public Aresta proxAdj(int v, Aresta a)
        {
            int pos = arestas.FindIndex(x => x == a);
            foreach (Aresta aresta in Arestas)
            {
                if ((aresta.AlunoA == v || aresta.AlunoB == v) && arestas.FindIndex(x => x == aresta) > pos)
                {
                    return aresta;
                }
            }
            return null;
        }

        public void imprime()
        {
            foreach (var aresta in arestas)
            {
                Console.WriteLine("{0}, {1}, {2}", aresta.AlunoA, aresta.AlunoB, aresta.Peso);
            }
        }

        public int get_numVertices()
        {
            return chefes.Length;
        }

        public bool isadjacente(int v1, int v2)
        {
            return arestas.Exists(x => (x.AlunoA == v1 && x.AlunoB == v2) || (x.AlunoB == v1 && x.AlunoA == v2));
        }

        public int Getgrau(int v1)
        {
            int contador = 0;
            foreach (var aresta in arestas)
            {
                if (aresta.AlunoA == v1 || aresta. AlunoB == v1)
                {
                    contador++;
                }
            }
            return contador;
        }

        public bool isRegular()
        {
            int grauBase = Getgrau(0);
            for (int i = 1; i < chefes.Length; i++)
            {
                if (Getgrau(i) != grauBase)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
