﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI_de_Gafos_2016
{
    public class Aresta
    {
        int alunoA, alunoB, peso;
        public Aresta(int alunoA, int alunoB, int peso)
        {
            this.alunoA = alunoA;
            this.alunoB = alunoB;
            this.peso = peso;
        }
        public Aresta()
        {
              
        }
        public int AlunoA
        {
            get
            {
                return alunoA;
            }

            set
            {
                alunoA = value;
            }
        }

        public int AlunoB
        {
            get
            {
                return alunoB;
            }

            set
            {
                alunoB = value;
            }
        }

        public int Peso
        {
            get
            {
                return peso;
            }

            set
            {
                peso = value;
            }
        }
    }
}
