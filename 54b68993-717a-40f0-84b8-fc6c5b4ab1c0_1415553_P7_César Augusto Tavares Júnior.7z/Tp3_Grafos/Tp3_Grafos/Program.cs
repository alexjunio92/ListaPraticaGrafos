﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Tp3_Grafos
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader Arquivo = new StreamReader(@"D:\César\Área de Trabalho\Tp3_Grafos\Teste.txt");
            string s_dadosbase;
            string s_conexoes;
            string[] vs_info,vs_aresta;
            int i_qtdvertice,i_qtdaresta;
            int[,] mi_Grafo;
            int[] vi_Vertices;
            int i_indice = 0;

            s_dadosbase = Arquivo.ReadLine();
            vs_info = s_dadosbase.Split(' ');
            i_qtdvertice = int.Parse(vs_info[0]);
            i_qtdaresta = int.Parse(vs_info[1]);

            mi_Grafo = new int[i_qtdvertice, i_qtdvertice];
            vi_Vertices = new int[i_qtdvertice];
            vs_aresta = new string[i_qtdaresta];

            for(int cont = 0; cont < i_qtdaresta; cont++)
            {                
                s_conexoes = Arquivo.ReadLine();
                vs_info = s_conexoes.Split(' ');
                if (i_indice < i_qtdvertice)
                {
                    vi_Vertices[i_indice] = int.Parse(vs_info[0]);
                    i_indice++;
                    vi_Vertices[i_indice] = int.Parse(vs_info[1]);
                    i_indice++;
                }

                vs_aresta[cont] = String.Join("",vs_info);
            }
            Console.WriteLine("Carga realizada com sucesso!");
            Console.ReadKey();

            mi_Grafo = MontarMatriz(vs_aresta, i_qtdvertice);
            ImprimeMatriz(mi_Grafo, i_qtdvertice);
            Console.ReadKey();


        }

        public static int[,] MontarMatriz(string [] Arestas, int qtdvertices)
        {
            int[,] Matriz_Retorno = new int [qtdvertices,qtdvertices];
            int valores;
            for (int linha = 0; linha < qtdvertices; linha++)
            {
                for (int coluna = 0; coluna < qtdvertices; coluna++)
                {
                    for (int contador = 0; contador < Arestas.Length; contador++)
                    {
                        valores = int.Parse(Arestas[contador]);
                        if (valores / 100 == linha + 1 && ((valores / 10) - (valores / 100 * 10)) == coluna + 1)
                        {
                            Matriz_Retorno[linha, coluna] = (valores) - (valores / 10 * 10);
                            contador = Arestas.Length;
                        }
                        else if (valores / 100 == coluna + 1 && ((valores / 10) - (valores / 100 * 10)) == linha + 1)
                        {
                            Matriz_Retorno[linha, coluna] = (valores) - (valores / 10 * 10);
                            contador = Arestas.Length;
                        }
                        else
                            Matriz_Retorno[linha, coluna] = 0;
                    }
                }
            }


            return Matriz_Retorno;
        }

        public static void ImprimeMatriz(int[,] matriz,int qtdvertice)
        {
            for (int linha = 0; linha < qtdvertice; linha++)
            {
                for (int coluna = 0; coluna < qtdvertice; coluna++)
                {
                    Console.Write(" " + matriz[linha, coluna] + " ");
                }
                Console.WriteLine();
            }
        }



    }
    

}
