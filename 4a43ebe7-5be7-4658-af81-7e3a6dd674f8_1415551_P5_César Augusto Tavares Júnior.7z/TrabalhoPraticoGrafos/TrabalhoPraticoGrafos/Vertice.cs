﻿/*Trabalho Pratico 1 - 8 Puzzle
Algoritmos em Grafos
Grupo: César Augusto Tavares Jr.
       Chayane Lisley da Costa Soares
       Karen Lorrayne de Carvalho
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoPraticoGrafos
{
    class Vertice
    {

        int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        string estado;

        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        bool verificado;

        public bool Verificado
        {
            get { return verificado; }
            set { verificado = value; }
        }

        int idPai;

        public int IdPai
        {
            get { return idPai; }
            set { idPai = value; }
        }

        string movimento;

        public string Movimento
        {
            get { return movimento; }
            set { movimento = value; }
        }

        public Vertice()
        {
            this.Id = 0;
            this.IdPai = 0;
            this.Verificado = false;
            this.Estado = "";
            this.Movimento = "";
        }

        /*Vertice será um objeto usado como nó da arvora que fara a busca e geração*/
        public Vertice(int id, int idpai, string estado, bool verificado, string movimento)
        {
            this.Id = id;
            this.IdPai = idpai;
            this.Verificado = verificado;
            this.Estado = estado;
            this.Movimento = movimento;
        }

    }
}
