﻿/*Trabalho Pratico 1 - 8 Puzzle
Algoritmos em Grafos
Grupo: César Augusto Tavares Jr.
       Chayane Lisley da Costa Soares
       Karen Lorrayne de Carvalho
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoPraticoGrafos
{
    class Program
    {
        /*Metodo recebe uma string de estado e retorna este estado montado em uam matriz 3 por 3*/
        public static int[,] CriaMatriz(string estado)
        {
            int[,] matriz = new int[3, 3];
            int contador = 0;
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 3; coluna++)
                {
                    int valor = estado[contador] - '0';
                    matriz[linha, coluna] = valor;
                    contador++;
                }
            }
            return matriz;
        }
        
        /*Metodo faz impressão em formato de matriz*/
        public static void Imprime(int[,] matriz)
        {

            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 3; coluna++)
                {
                    Console.Write(matriz[linha, coluna] + "");
                }
                Console.WriteLine();
            }
        }
        
        /*Metodo recer uma matriz como parametro de entrada e retorna uma string com o estado*/
        public static string EstadosRetorno(int[,] Matriz)
        {
            string estado = "";
            int cont = 0;
            string[] estadoArr = new string[9];       


            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 3; coluna++)
                {
                   estadoArr[cont] = (Matriz[linha, coluna]).ToString();
                    cont++;
                }
            }
          
            estado = String.Join("", estadoArr);
            return estado;
        }

        /*Metodo busca a linha e coluna do valor 0 ou espaço em branco ne uma matriz*/
        public static int RecuperaZero(int[,] Matriz)
        {
            int zero = 0;
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 3; coluna++)
                {
                    if (Matriz[linha, coluna] == 0)
                    {
                        zero = coluna * 10;
                        zero = zero + linha;
                    }
                }
            }

            return zero;
        }

        /*Verifica se o jogo já está resolvido*/
        public static bool ResultadoAlcancado(string estado)
        {
            if (estado == "123456780")
                return true;
            else
                return false;
        }
        
        /*Metodo retorna se o movimento desejado é possivel ou não*/
        public static bool VerificaMovimento(char movimento, int Vizinho)
        {

            //Verifica se os movimentos são possiveis
            //Verifica movimento Cima
            if (movimento == 'C')
            {
                //Verifica se a Linha é valida (dentro de 3x3)
                if (RetornaLinha(Vizinho) < 2)
                    return true;
                else
                    return false;
            }
            //verifica movimento baixo
            else if (movimento == 'B')
            {
                //Verifica se a Linha é valida (dentro de 3x3)
                if (RetornaLinha(Vizinho) > 0)
                    return true;
                else
                    return false;
            }
            //verifica movimento esquerda
            else if (movimento == 'E')
            {
                //Verifica se a Coluna é valida (dentro de 3x3)
                if (RetornaColuna(Vizinho) < 2)
                    return true;
                else
                    return false;
            }
            //verifica movimento direita
            else if (movimento == 'D')
            {
                //Verifica se a Coluna é valida (dentro de 3x3)
                if (RetornaColuna(Vizinho) > 0)
                    return true;
                else
                    return false;
            }
            else
                return false;

        }
        
        /*Manipula variavel com linha e coluna do espaço em branco ou 0  e retorna apenas a coluna*/
        public static int RetornaLinha(int zero)
        {
            //pega linha da variavel que indica a posicao de zero ou branco
            return (zero - zero / 10 * 10);
        }
        /*Manipula variavel com linha e coluna do espaço em branco ou 0  e retorna apenas a linha*/
        public static int RetornaColuna(int zero)
        {
            //pega coluna da variavel que indica a posicao de zero ou branco
            return zero / 10;
        }

        //Metodo que executa a troca de posição do espaço em branco realizando um movimento.
        public static int[,] ExecutaMovimento(char movimento,int [,] MatrixAtual)
        {
            int[,] MatrizAux = new int[3, 3];

            if (movimento == 'C')
            {
                
                MatrizAux = new int[3, 3];
                MatrizAux = MatrixAtual;
                int valor, coluna, linha, valorcima;
                //Recupera o valor do espaço branco na matriz atual
                valor = RecuperaZero(MatrixAtual);
                //recupera a coluna
                coluna = RetornaColuna(valor);
                //recupera a linha
                linha = RetornaLinha(valor);
                //busca o valor que assumira branco
                valorcima = MatrixAtual[linha + 1, coluna];
                //sobe valor
                MatrizAux[linha, coluna] = valorcima;
                //desce branco
                MatrizAux[linha + 1, coluna] = 0;
                //retorna a matriz nova
                return MatrizAux;
            }
            else if (movimento == 'B')
            {

                MatrizAux = new int[3, 3];
                MatrizAux = MatrixAtual;
                int valor, coluna, linha, valorbaixo;
                valor = RecuperaZero(MatrixAtual);
                coluna = RetornaColuna(valor);
                linha = RetornaLinha(valor);
                //busca valor que assumira branco
                valorbaixo = MatrixAtual[linha - 1, coluna];
                //desce valor
                MatrizAux[linha, coluna] = valorbaixo;
                //sobe branco
                MatrizAux[linha - 1, coluna] = 0;
                //retorna matriz nova
                return MatrizAux;
            }
            else if (movimento == 'D')
            {

                MatrizAux = new int[3, 3];
                MatrizAux = MatrixAtual;
                int valor, coluna, linha, valordireita;
                valor = RecuperaZero(MatrixAtual);
                coluna = RetornaColuna(valor);
                linha = RetornaLinha(valor);
                valordireita = MatrixAtual[linha, coluna - 1];
                //move valor
                MatrizAux[linha, coluna] = valordireita;
                //move branco
                MatrizAux[linha, coluna - 1] = 0;
                //retorna matriz nova
                return MatrizAux;
            }
            else if (movimento == 'E')
            {

                MatrizAux = new int[3, 3];
                MatrizAux = MatrixAtual;
                int valor, coluna, linha, valoresquerda;
                valor = RecuperaZero(MatrixAtual);
                coluna = RetornaColuna(valor);
                linha = RetornaLinha(valor);
                valoresquerda = MatrixAtual[linha, coluna + 1];
                //move valor
                MatrizAux[linha, coluna] = valoresquerda;
                //move branco
                MatrizAux[linha, coluna + 1] = 0;
                //retorna nova matriz
                return MatrizAux;
            }
            else return MatrixAtual;
        }

        public static void BuscaSucessores(Vertice Item)
        {
            Vertice Aux = new Vertice();
            Aux = Item;
            int[,] Matriz = new int[3, 3];

            //Verifica se chegou ao resultado
            if (ResultadoAlcancado(Aux.Estado) == true)
            {
                //enquanto não chegar no primeira movimento adiciona os caminhos na lista ResultadoFinal
                do
                {
                    
                    int cont = 0;
                    while (cont < Principal.Lista.Count && Aux.IdPai != 0)
                    {
                        //Adiciona Vertice atual e altera para o Vertice anterior
                        if (Aux.IdPai == Principal.Lista[cont].Id)
                        {
                            ResultadoFinal.Lista.Add(Aux);
                            Aux = Principal.Lista[cont];
                        }
                        //se for primeiro vertice adiciona na lista
                        else if (Aux.IdPai == 0)
                        {
                            ResultadoFinal.Lista.Add(Aux);
                            Aux = Principal.Lista[cont];
                        }

                        cont++;
                    }
                } while (Aux.IdPai != 0);
                //limpa fila de verificação
                FilaVerificação.Clear();
                Aux = new Vertice(0, 0, "", false, "Final");
                //enfileira vertice de referencia final
                FilaVerificação.Enqueue(Aux);
            }
            else
            {

                //Criar Matriz
                Matriz = CriaMatriz(Aux.Estado);
                string estadonovo;

                //Verifica se pode subir
                if (VerificaMovimento('C', RecuperaZero(Matriz)) == true)
                {
                    //Move
                    Matriz = ExecutaMovimento('C', Matriz);
                    //Recebe string com o novo estado
                    estadonovo = EstadosRetorno(Matriz);
                    //Cria Item Vertice com armazenando um novo id, o id do movimento anterior como id pai, estado e movimento feito
                    Aux = new Vertice(id, Item.Id, estadonovo, false, "C");
                    //Adiciona a Fila de Verificação
                    FilaVerificação.Enqueue(Aux);
                    //Adiciona na Lista de Vertices
                    Principal.Lista.Add(Aux);
                    id++;
                }
                //Limpa Matriz
                Aux = Item;
                Matriz = CriaMatriz(Aux.Estado);
                //Verifica se pode descer
                if (VerificaMovimento('B', RecuperaZero(Matriz)) == true)
                {
                    //Move
                    Matriz = ExecutaMovimento('B', Matriz);
                    //Recebe string com o novo estado
                    estadonovo = EstadosRetorno(Matriz);
                    //Cria Item Vertice com armazenando um novo id, o id do movimento anterior como id pai, estado e movimento feito
                    Aux = new Vertice(id, Item.Id, estadonovo, false, "B");
                    //Adiciona a Fila de Verificação
                    FilaVerificação.Enqueue(Aux);
                    //Adiciona na Lista de Vertices
                    Principal.Lista.Add(Aux);
                    id++;
                }
                //Limpa Matriz
                Aux = Item;
                Matriz = CriaMatriz(Aux.Estado);
                //Verifica se pode ir para a direita
                if (VerificaMovimento('D', RecuperaZero(Matriz)) == true)
                {
                    //Move
                    Matriz = ExecutaMovimento('D', Matriz);
                    //Recebe string com o novo estado
                    estadonovo = EstadosRetorno(Matriz);
                    //Cria Item Vertice com armazenando um novo id, o id do movimento anterior como id pai, estado e movimento feito
                    Aux = new Vertice(id, Item.Id, estadonovo, false, "D");
                    //Adiciona a Fila de Verificação
                    FilaVerificação.Enqueue(Aux);
                    //Adiciona na Lista de Vertices
                    Principal.Lista.Add(Aux);
                    id++;
                }
                //Limpa Matriz
                Aux = Item;
                Matriz = CriaMatriz(Aux.Estado);
                //Verifica se pode ir para a esquerda
                if (VerificaMovimento('E', RecuperaZero(Matriz)) == true)
                {
                    //Move
                    Matriz = ExecutaMovimento('E', Matriz);
                    //Recebe string com o novo estado
                    estadonovo = EstadosRetorno(Matriz);
                    //Cria Item Vertice com armazenando um novo id, o id do movimento anterior como id pai, estado e movimento feito
                    Aux = new Vertice(id, Item.Id, estadonovo, false, "E");
                    //Adiciona a Fila de Verificação
                    FilaVerificação.Enqueue(Aux);
                    //Adiciona na Lista de Vertices
                    Principal.Lista.Add(Aux);
                    id ++;
                }
            }
        }

        public static Queue<Vertice> FilaVerificação = new Queue<Vertice>();
        public static ListaEstados Principal = new ListaEstados();
        public static ListaEstados ResultadoFinal = new ListaEstados();
        public static int id;


        static void Main(string[] args)
        {

            string estado;
            string confirm;
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Seja bem vindo! Favor digitar em sequencia que deseja resolver. \nExemplo : (152480763)");
                estado = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Deseja seguir para a resolução da sequencia: " + estado + " S - Sim  N - Não");
                confirm = Console.ReadLine();
                if (ResultadoAlcancado(estado) == true)
                {
                    Console.Clear();
                    Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                    Console.WriteLine();
                    Console.WriteLine("A sequencia digitada já esta ordenada!");
                    confirm = "N";
                    Console.ReadKey();
                }
            } while (confirm != "S");
            
            id = 1;
            
            Vertice Raiz = new Vertice();
            Raiz.Estado = estado;
            Raiz.Id = id;
            Raiz.IdPai = id-1;
            Raiz.Verificado = false;
            Raiz.Movimento = "";
            Principal.Lista.Add(Raiz);
            FilaVerificação.Enqueue(Raiz);
            Vertice Auxiliar = new Vertice();
            int[,] MatrixdeManipulação = new int[3, 3];
            id++;

           
            do
            {
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Realizando os calculos. Por favor aguarde.");
                Auxiliar = FilaVerificação.Peek();
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Realizando os calculos. Por favor aguarde..");
                FilaVerificação.Dequeue();
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Realizando os calculos. Por favor aguarde...");
                BuscaSucessores(Auxiliar);
                Console.Clear();
                Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
                Console.WriteLine();
                Console.WriteLine("Realizando os calculos. Por favor aguarde....");
            } while (FilaVerificação.Peek().Movimento != "Final");

            Auxiliar = ResultadoFinal.Lista[0];
            Console.Clear();
            Console.WriteLine("\t\t\t***** 8 - Puzzle Solver *****");
            Console.WriteLine();
            Console.WriteLine("\nA sequencia " + estado + " foi resolvida com sucesso!");
            Console.WriteLine("Movimentos Necessarios = " + ResultadoFinal.Lista.Count);
            Console.Write("Movimentos Realizados: ");
            for (int i = ResultadoFinal.Lista.Count-1; i >= 0 ; i--)
            {
                Console.Write(ResultadoFinal.Lista[i].Movimento);
            }
            Console.ReadKey();
        }
    }
}
