﻿/*Trabalho Pratico 1 - 8 Puzzle
Algoritmos em Grafos
Grupo: César Augusto Tavares Jr.
       Chayane Lisley da Costa Soares
       Karen Lorrayne de Carvalho
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoPraticoGrafos
{
    class ListaEstados
    {
        public List<Vertice> Lista;

        /*Lista de Vertices para armazenamento dos nos*/
        public ListaEstados()
        {
            this.Lista = new List<Vertice>();
        }
    }
}
